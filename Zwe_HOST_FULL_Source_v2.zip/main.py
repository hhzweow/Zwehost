import os, json, threading, webbrowser
from kivy.app import App
from kivy.lang import Builder
from kivy.clock import Clock
from kivy.properties import StringProperty
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout
from auth import AuthStore
from runner import BotRunner
from packages import install_package

KV = r"""
#:import dp kivy.metrics.dp
<DarkButton@Button>:
    background_normal: ''
    background_color: (.04,.18,.29,1)
    color: (.88,.95,1,1)
    size_hint_y: None
    height: dp(48)
<Root>:
    BoxLayout:
        orientation:'vertical'
        canvas.before:
            Color:
                rgba:(.018,.035,.06,1)
            Rectangle:
                pos:self.pos
                size:self.size
        BoxLayout:
            size_hint_y:None
            height:dp(62)
            padding:dp(16),dp(8)
            canvas.before:
                Color:
                    rgba:(.025,.075,.12,1)
                Rectangle:
                    pos:self.pos
                    size:self.size
            Label:
                text:'[b]ZWE [color=32B8FF]HOST[/color][/b]'
                markup:True
                font_size:'22sp'
                halign:'left'
            Label:
                text:app.plan
                color:(.2,.9,.52,1)
                size_hint_x:None
                width:dp(65)
        ScreenManager:
            id:sm
            LoginScreen:
                name:'login'
            SignupScreen:
                name:'signup'
            Dashboard:
                name:'home'
            RunScreen:
                name:'run'
            BotsScreen:
                name:'bots'
            PackagesScreen:
                name:'packages'
            FilesScreen:
                name:'files'
            PurchasesScreen:
                name:'purchases'
            ProfileScreen:
                name:'profile'
            AdminScreen:
                name:'admin'
        BoxLayout:
            size_hint_y:None
            height:dp(58)
            spacing:dp(2)
            padding:dp(3)
            canvas.before:
                Color:
                    rgba:(.025,.075,.12,1)
                Rectangle:
                    pos:self.pos
                    size:self.size
            DarkButton:
                text:'Home'
                on_release:sm.current='home' if app.logged else 'login'
            DarkButton:
                text:'Run'
                on_release:sm.current='run' if app.logged else 'login'
            DarkButton:
                text:'Bots'
                on_release:sm.current='bots' if app.logged else 'login'; app.refresh_bots()
            DarkButton:
                text:'More'
                on_release:sm.current='profile' if app.logged else 'login'

<LoginScreen>:
    BoxLayout:
        orientation:'vertical'
        padding:dp(22)
        spacing:dp(12)
        Widget:
            size_hint_y:.4
        Label:
            text:'[b]Welcome to Zwe HOST[/b]\\n[color=8AA9C3]Sign in to your hosting workspace[/color]'
            markup:True
            font_size:'21sp'
            size_hint_y:None
            height:dp(80)
        TextInput:
            id:login_user
            hint_text:'Username'
            multiline:False
            size_hint_y:None
            height:dp(48)
        TextInput:
            id:login_pass
            hint_text:'Password'
            password:True
            multiline:False
            size_hint_y:None
            height:dp(48)
        DarkButton:
            text:'LOGIN'
            background_color:(.02,.48,.30,1)
            on_release:app.login(login_user.text,login_pass.text)
        DarkButton:
            text:'Create account'
            on_release:app.root.ids.sm.current='signup'
        Label:
            id:login_msg
            text:''
            color:(1,.35,.35,1)
        Widget:
            size_hint_y:.4

<SignupScreen>:
    BoxLayout:
        orientation:'vertical'
        padding:dp(22)
        spacing:dp(12)
        Label:
            text:'[b]Create account[/b]'
            markup:True
            font_size:'23sp'
            size_hint_y:None
            height:dp(55)
        TextInput:
            id:su_user
            hint_text:'Choose username'
            multiline:False
            size_hint_y:None
            height:dp(48)
        TextInput:
            id:su_pass
            hint_text:'Choose password (8+ characters)'
            password:True
            multiline:False
            size_hint_y:None
            height:dp(48)
        TextInput:
            id:su_confirm
            hint_text:'Confirm password'
            password:True
            multiline:False
            size_hint_y:None
            height:dp(48)
        DarkButton:
            text:'CREATE FREE ACCOUNT'
            on_release:app.signup(su_user.text,su_pass.text,su_confirm.text)
        DarkButton:
            text:'Back to login'
            on_release:app.root.ids.sm.current='login'
        Label:
            id:signup_msg
            text:'New accounts start on FREE plan.'
            color:(.6,.75,.86,1)

<Dashboard>:
    BoxLayout:
        orientation:'vertical'
        padding:dp(16)
        spacing:dp(12)
        Label:
            text:'[b]Hosting Dashboard[/b]'
            markup:True
            font_size:'23sp'
            size_hint_y:None
            height:dp(42)
            halign:'left'
        GridLayout:
            cols:2
            spacing:dp(10)
            size_hint_y:None
            height:dp(118)
            BoxLayout:
                orientation:'vertical'
                padding:dp(10)
                canvas.before:
                    Color:
                        rgba:(.035,.15,.21,1)
                    RoundedRectangle:
                        pos:self.pos
                        size:self.size
                        radius:[dp(12)]
                Label:
                    text:'ACTIVE BOTS'
                Label:
                    text:app.active_count
                    font_size:'30sp'
                    color:(.2,.9,.52,1)
            BoxLayout:
                orientation:'vertical'
                padding:dp(10)
                canvas.before:
                    Color:
                        rgba:(.12,.09,.18,1)
                    RoundedRectangle:
                        pos:self.pos
                        size:self.size
                        radius:[dp(12)]
                Label:
                    text:'CURRENT PLAN'
                Label:
                    text:app.plan
                    font_size:'25sp'
                    color:(.2,.9,.52,1)
        DarkButton:
            text:'+ Run a bot'
            background_color:(.02,.48,.30,1)
            on_release:app.root.ids.sm.current='run'
        DarkButton:
            text:'Running bots'
            on_release:app.root.ids.sm.current='bots'; app.refresh_bots()
        DarkButton:
            text:'Python packages'
            on_release:app.root.ids.sm.current='packages'
        DarkButton:
            text:'Files manager'
            on_release:app.root.ids.sm.current='files'; app.refresh_files()
        DarkButton:
            text:'Purchases / PRO'
            on_release:app.root.ids.sm.current='purchases'
        Label:
            text:'[color=FFCB66]Background uptime depends on Android, power and network conditions.[/color]'
            markup:True
            text_size:self.width,None
            size_hint_y:None
            height:dp(52)

<RunScreen>:
    BoxLayout:
        orientation:'vertical'
        padding:dp(16)
        spacing:dp(9)
        Label:
            text:'[b]Run Python bot[/b]'
            markup:True
            font_size:'22sp'
            size_hint_y:None
            height:dp(42)
        TextInput:
            id:bot_path
            hint_text:'Bot .py path inside app workspace'
            multiline:False
            size_hint_y:None
            height:dp(48)
        DarkButton:
            text:'Choose bot file'
            on_release:app.pick_file()
        DarkButton:
            text:'RUN BOT'
            background_color:(.02,.5,.3,1)
            on_release:app.start_bot(bot_path.text)
        DarkButton:
            text:'+ Run another bot'
            on_release:app.root.ids.sm.current='run'
        Label:
            text:'[b]Console output[/b]'
            markup:True
            size_hint_y:None
            height:dp(26)
        TextInput:
            id:console
            readonly:True
            background_color:(.008,.02,.035,1)
            foreground_color:(.3,.95,.6,1)
            text:'Zwe HOST ready.\\n'

<BotsScreen>:
    BoxLayout:
        orientation:'vertical'
        padding:dp(14)
        spacing:dp(8)
        Label:
            text:'[b]Running Bots[/b]'
            markup:True
            font_size:'22sp'
            size_hint_y:None
            height:dp(42)
        ScrollView:
            GridLayout:
                id:bot_list
                cols:1
                spacing:dp(8)
                size_hint_y:None
                height:self.minimum_height
        DarkButton:
            text:'Refresh'
            on_release:app.refresh_bots()

<PackagesScreen>:
    BoxLayout:
        orientation:'vertical'
        padding:dp(16)
        spacing:dp(10)
        Label:
            text:'[b]Package manager[/b]'
            markup:True
            font_size:'22sp'
            size_hint_y:None
            height:dp(42)
        TextInput:
            id:package_name
            hint_text:'Package name, e.g. requests'
            multiline:False
            size_hint_y:None
            height:dp(48)
        DarkButton:
            text:'Install with pip'
            on_release:app.add_package(package_name.text)
        Label:
            text:'Only packages compatible with the bundled Android Python runtime can install. Native dependencies may not work.'
            text_size:self.width,None

<FilesScreen>:
    BoxLayout:
        orientation:'vertical'
        padding:dp(16)
        spacing:dp(8)
        Label:
            text:'[b]Bot workspace[/b]'
            markup:True
            font_size:'22sp'
            size_hint_y:None
            height:dp(42)
        DarkButton:
            text:'Refresh files'
            on_release:app.refresh_files()
        ScrollView:
            Label:
                id:file_list
                text:''
                text_size:self.width,None
                size_hint_y:None
                height:self.texture_size[1]

<PurchasesScreen>:
    BoxLayout:
        orientation:'vertical'
        padding:dp(18)
        spacing:dp(12)
        Label:
            text:'[b]Upgrade to PRO[/b]'
            markup:True
            font_size:'24sp'
            size_hint_y:None
            height:dp(48)
        Label:
            text='FREE: up to 2 bots / 2-hour session\\nPRO: up to 5 bots / 24-hour session'
            text_size:self.width,None
        DarkButton:
            text:'Contact @suvorow1 on Telegram'
            on_release:app.contact_admin()
        Label:
            text:'PRO is activated by an authorized administrator after purchase verification. This starter project does not process payments.'
            text_size:self.width,None

<ProfileScreen>:
    BoxLayout:
        orientation:'vertical'
        padding:dp(16)
        spacing:dp(10)
        Label:
            text:'[b]Profile & settings[/b]'
            markup:True
            font_size:'22sp'
            size_hint_y:None
            height:dp(42)
        Label:
            text:'User: '+app.username+'\\nPlan: '+app.plan
        DarkButton:
            text:'Purchases'
            on_release:app.root.ids.sm.current='purchases'
        DarkButton:
            text:'Admin panel'
            on_release:app.open_admin()
        DarkButton:
            text:'Log out'
            on_release:app.logout()

<AdminScreen>:
    BoxLayout:
        orientation:'vertical'
        padding:dp(16)
        spacing:dp(8)
        Label:
            text:'[b]Admin Panel[/b]'
            markup:True
            font_size:'22sp'
            size_hint_y:None
            height:dp(42)
        Label:
            text:'Admin access must be assigned by a trusted backend. No admin password is embedded in this APK.'
            text_size:self.width,None
        TextInput:
            id:target_user
            hint_text:'Username to grant PRO'
            multiline:False
            size_hint_y:None
            height:dp(48)
        DarkButton:
            text:'Grant PRO (backend integration required)'
            on_release:app.show_msg('Connect the backend and verify admin role before granting PRO.')
"""

class Root(Screen): pass
class LoginScreen(Screen): pass
class SignupScreen(Screen): pass
class Dashboard(Screen): pass
class RunScreen(Screen): pass
class BotsScreen(Screen): pass
class PackagesScreen(Screen): pass
class FilesScreen(Screen): pass
class PurchasesScreen(Screen): pass
class ProfileScreen(Screen): pass
class AdminScreen(Screen): pass

class ZweHostApp(App):
    plan=StringProperty("FREE")
    username=StringProperty("Guest")
    active_count=StringProperty("0")
    logged=False
    def build(self):
        self.title="Zwe HOST"
        self.store=AuthStore(self.user_data_dir)
        self.runner=BotRunner(self.workspace, self.log_line, self.changed)
        Builder.load_string(KV)
        root=Root()
        Clock.schedule_once(lambda dt:self.restore_session(),.2)
        return root
    @property
    def workspace(self):
        p=os.path.join(self.user_data_dir,"workspace")
        os.makedirs(p,exist_ok=True)
        return p
    def restore_session(self):
        u=self.store.current_user()
        if u:
            self.set_user(u)
            self.root.ids.sm.current="home"
    def set_user(self,u):
        self.username=u["username"]; self.plan=u["plan"].upper(); self.logged=True
        self.runner.set_plan(self.plan)
        self.refresh_bots()
    def signup(self,u,p,c):
        try:
            if p!=c: raise ValueError("Passwords do not match.")
            user=self.store.signup(u,p)
            self.set_user(user); self.root.ids.sm.current="home"
        except Exception as e: self.show_msg(str(e))
    def login(self,u,p):
        try:
            user=self.store.login(u,p)
            self.set_user(user); self.root.ids.sm.current="home"
        except Exception as e:
            self.root.ids.sm.get_screen("login").ids.login_msg.text=str(e)
    def logout(self):
        self.store.logout(); self.logged=False; self.username="Guest"; self.plan="FREE"
        self.root.ids.sm.current="login"
    def start_bot(self,path):
        try:
            if not path: raise ValueError("Enter a bot file path.")
            if not os.path.isabs(path): path=os.path.join(self.workspace,path)
            bid=self.runner.start(path)
            self.log_line(f"Started {os.path.basename(path)} [{bid}]")
            self.refresh_bots()
        except Exception as e: self.show_msg(str(e))
    def refresh_bots(self):
        if not hasattr(self,"runner"): return
        bots=self.runner.list_bots()
        self.active_count=str(sum(x["status"]=="RUNNING" for x in bots))
        try:
            grid=self.root.ids.sm.get_screen("bots").ids.bot_list
            grid.clear_widgets()
            for b in bots:
                row=BoxLayout(size_hint_y=None,height="52dp",spacing=5)
                row.add_widget(Label(text=f'{b["name"]} • {b["status"]}'))
                from kivy.uix.button import Button
                stop=Button(text="STOP",size_hint_x=None,width="70dp")
                stop.bind(on_release=lambda w,i=b["id"]:self.runner.stop(i))
                delete=Button(text="DEL",size_hint_x=None,width="60dp")
                delete.bind(on_release=lambda w,i=b["id"]:self.runner.delete(i))
                row.add_widget(stop); row.add_widget(delete); grid.add_widget(row)
        except Exception: pass
    def changed(self):
        Clock.schedule_once(lambda dt:self.refresh_bots(),0)
    def log_line(self,line):
        def add(dt):
            try:
                f=self.root.ids.sm.get_screen("run").ids.console
                f.text += line+"\n"
            except Exception: pass
        Clock.schedule_once(add,0)
    def pick_file(self):
        self.show_msg("Copy your .py bot into the app workspace, then enter its filename. Android system file-picker integration depends on the selected device/API.")
    def add_package(self,name):
        try:
            if not name.strip(): raise ValueError("Enter a package name.")
            self.log_line("Installing "+name+" ...")
            threading.Thread(target=self._install,args=(name,),daemon=True).start()
        except Exception as e:self.show_msg(str(e))
    def _install(self,name):
        ok,msg=install_package(name)
        self.log_line(msg)
    def refresh_files(self):
        try:
            names=os.listdir(self.workspace)
            self.root.ids.sm.get_screen("files").ids.file_list.text="\n".join(names) if names else "Workspace is empty."
        except Exception: pass
    def open_admin(self):
        if self.store.is_admin():
            self.root.ids.sm.current="admin"
        else:
            self.show_msg("Admin access is not assigned to this account.")
    def contact_admin(self):
        webbrowser.open("https://t.me/suvorow1")
    def show_msg(self,msg):
        Popup(title="Zwe HOST",content=Label(text=str(msg)),size_hint=(.88,.36)).open()
    def on_stop(self):
        # Bot processes are not guaranteed to survive app termination.
        pass

if __name__=="__main__":
    ZweHostApp().run()
