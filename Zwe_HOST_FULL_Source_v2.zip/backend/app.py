import os, sqlite3, time
from fastapi import FastAPI, HTTPException, Depends
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel
from passlib.context import CryptContext
from jose import jwt, JWTError

DB=os.getenv("ZWE_DB","zwe_backend.sqlite3")
SECRET=os.getenv("ZWE_SECRET")
ADMIN_USER=os.getenv("ZWE_ADMIN_USER")
ADMIN_PASSWORD=os.getenv("ZWE_ADMIN_PASSWORD")
if not SECRET: raise RuntimeError("Set ZWE_SECRET environment variable.")
pwd=CryptContext(schemes=["bcrypt"],deprecated="auto")
oauth=OAuth2PasswordBearer(tokenUrl="/login")
app=FastAPI(title="Zwe HOST API")
def conn():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
with conn() as c:
    c.execute("""CREATE TABLE IF NOT EXISTS users(
        username TEXT PRIMARY KEY,password_hash TEXT NOT NULL,plan TEXT NOT NULL DEFAULT 'free',
        is_admin INTEGER NOT NULL DEFAULT 0)""")
    if ADMIN_USER and ADMIN_PASSWORD:
        c.execute("INSERT OR IGNORE INTO users VALUES(?,?,?,1)",
                  (ADMIN_USER,pwd.hash(ADMIN_PASSWORD),"free"))
class Credentials(BaseModel):
    username:str
    password:str
class Grant(BaseModel):
    username:str
    plan:str="pro"
def token_for(u):
    return jwt.encode({"sub":u["username"],"exp":int(time.time())+86400},SECRET,algorithm="HS256")
def current(token=Depends(oauth)):
    try:
        data=jwt.decode(token,SECRET,algorithms=["HS256"])
        with conn() as c:r=c.execute("SELECT * FROM users WHERE username=?",(data["sub"],)).fetchone()
        if not r: raise HTTPException(401,"Unknown user")
        return dict(r)
    except JWTError: raise HTTPException(401,"Invalid token")
@app.post("/signup")
def signup(x:Credentials):
    if len(x.username)<3 or len(x.password)<8: raise HTTPException(400,"Username/password too short")
    with conn() as c:
        try:c.execute("INSERT INTO users(username,password_hash) VALUES(?,?)",(x.username,pwd.hash(x.password)))
        except sqlite3.IntegrityError:raise HTTPException(409,"Username exists")
    return {"access_token":token_for({"username":x.username}),"token_type":"bearer","plan":"free"}
@app.post("/login")
def login(x:Credentials):
    with conn() as c:r=c.execute("SELECT * FROM users WHERE username=?",(x.username,)).fetchone()
    if not r or not pwd.verify(x.password,r["password_hash"]):raise HTTPException(401,"Invalid login")
    return {"access_token":token_for(dict(r)),"token_type":"bearer","plan":r["plan"]}
@app.get("/me")
def me(u=Depends(current)):return {"username":u["username"],"plan":u["plan"],"is_admin":bool(u["is_admin"])}
@app.get("/admin/users")
def users(u=Depends(current)):
    if not u["is_admin"]:raise HTTPException(403,"Admin only")
    with conn() as c:return [dict(r) for r in c.execute("SELECT username,plan,is_admin FROM users")]
@app.post("/admin/grant")
def grant(x:Grant,u=Depends(current)):
    if not u["is_admin"]:raise HTTPException(403,"Admin only")
    if x.plan not in ("free","pro"):raise HTTPException(400,"Invalid plan")
    with conn() as c:
        cur=c.execute("UPDATE users SET plan=? WHERE username=?",(x.plan,x.username))
        if cur.rowcount==0:raise HTTPException(404,"User not found")
    return {"ok":True,"username":x.username,"plan":x.plan}
