import subprocess, sys, re
SAFE=re.compile(r"^[A-Za-z0-9_.-]+([<>=!~].*)?$")
def install_package(name):
    name=name.strip()
    if not SAFE.fullmatch(name): return False,"Invalid package name."
    try:
        p=subprocess.run([sys.executable,"-m","pip","install",name],
            capture_output=True,text=True,timeout=600)
        return p.returncode==0,(p.stdout+"\n"+p.stderr)[-5000:]
    except Exception as e:return False,str(e)
