# Zwe HOST — Full source project

Android-first Kivy project plus a FastAPI backend starter.

## Included
- Mobile dashboard, login/signup UI, persistent local session
- Bot run/list/stop/delete screens
- Separate subprocess runner and FREE/PRO limits (2 bots/2 hours; 5 bots/24 hours)
- Package installation screen
- Workspace/file listing
- Purchases/contact flow to @suvorow1
- Backend starter with password hashing, JWT, admin-only PRO grant
- Buildozer config and `.github/workflows/build.yml` GitHub Actions APK workflow
- Foreground-service entry point scaffold

## Honest release status
This is a complete **source starter**, not a verified production APK or guaranteed 24/7 hosting product.
The Python runner uses subprocesses in the app process environment. The included Android service is a
foreground-service scaffold and does not yet supervise bot subprocesses or recover them after process death.
The UI currently uses a workspace path field; Android Storage Access Framework file picker is not wired.
Package installs depend on the bundled Python environment and compatible wheels.
Backend API is separate and must be deployed and connected to the app before cloud accounts/admin/PRO work.
A public server, domain, TLS, secrets, payment provider, and device testing are not included.

## Admin bootstrap
Never hardcode an admin password in the APK or GitHub. On the backend host set:
- `ZWE_SECRET` to a long random secret
- `ZWE_ADMIN_USER` to the chosen admin username
- `ZWE_ADMIN_PASSWORD` to a unique admin password
Then start: `uvicorn app:app --host 0.0.0.0 --port 8000`
Use HTTPS in production. Do not commit `.env` or secrets.
The password previously sent in chat is not embedded in this project; change it if it is used anywhere else.

## Build APK with GitHub
1. Create a GitHub repository and upload all project files to its root.
2. Open Actions → Build Zwe HOST Android APK → Run workflow.
3. Download artifact `Zwe-HOST-debug-APK` from a successful run.
4. Test on a spare Android device. The workflow may need dependency adjustments as Buildozer/SDK/NDK versions change.

## Backend
`cd backend`, install `requirements.txt`, set environment variables above, then run `uvicorn app:app --host 0.0.0.0 --port 8000`.
The mobile app is not yet wired to these API endpoints; backend integration is a required release task.

## Android background behavior
Foreground service + notification and battery optimization settings can improve uptime, but Android,
OEM battery managers, force-stop, reboot, battery depletion and network loss can still interrupt bots.
No Android-only app can guarantee continuous 24/7 execution in all conditions.
