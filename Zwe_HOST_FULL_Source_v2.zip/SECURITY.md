# Security notes
- Bot scripts are executable code. Only run code you trust.
- Do not publish bot tokens, passwords, API keys, or `.env` files.
- Client-side plan labels are not authoritative. Backend must validate every PRO/admin action.
- Admin role is assigned only by backend bootstrap configuration.
- The API requires HTTPS and a strong random `ZWE_SECRET` when deployed publicly.
- This starter has not undergone a security audit.
