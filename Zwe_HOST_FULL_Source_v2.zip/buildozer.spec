[app]
title = Zwe HOST
package.name = zwehost
package.domain = com.zwe
source.dir = .
source.include_exts = py,kv,png,jpg,atlas,txt,md,json
version = 1.0.0
requirements = python3,kivy
orientation = portrait
fullscreen = 0
android.permissions = INTERNET,FOREGROUND_SERVICE,WAKE_LOCK,POST_NOTIFICATIONS,REQUEST_IGNORE_BATTERY_OPTIMIZATIONS
android.api = 35
android.minapi = 23
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True
# Service declaration syntax can vary with python-for-android / Buildozer versions.
services = hosting:service/main.py:foreground

[buildozer]
log_level = 2
warn_on_root = 1
