import os, sqlite3, hashlib, secrets, re
class AuthStore:
    def __init__(self, data_dir):
        os.makedirs(data_dir,exist_ok=True)
        self.db=os.path.join(data_dir,"accounts.sqlite3")
        self.session=os.path.join(data_dir,"session.json")
        with sqlite3.connect(self.db) as c:
            c.execute("""CREATE TABLE IF NOT EXISTS users(
                username TEXT PRIMARY KEY, salt TEXT NOT NULL, password_hash TEXT NOT NULL,
                plan TEXT NOT NULL DEFAULT 'free', is_admin INTEGER NOT NULL DEFAULT 0
            )""")
    def _hash(self,password,salt):
        return hashlib.pbkdf2_hmac("sha256",password.encode(),bytes.fromhex(salt),240000).hex()
    def signup(self,username,password):
        username=username.strip()
        if not re.fullmatch(r"[A-Za-z0-9_]{3,24}",username): raise ValueError("Username: 3-24 letters, numbers or underscore.")
        if len(password)<8: raise ValueError("Password must contain at least 8 characters.")
        salt=secrets.token_hex(16); h=self._hash(password,salt)
        try:
            with sqlite3.connect(self.db) as c:
                c.execute("INSERT INTO users(username,salt,password_hash) VALUES(?,?,?)",(username,salt,h))
        except sqlite3.IntegrityError: raise ValueError("Username already exists.")
        return self._save_session(username)
    def login(self,username,password):
        with sqlite3.connect(self.db) as c:
            row=c.execute("SELECT salt,password_hash FROM users WHERE username=?",(username.strip(),)).fetchone()
        if not row or not secrets.compare_digest(self._hash(password,row[0]),row[1]):
            raise ValueError("Incorrect username or password.")
        return self._save_session(username.strip())
    def _user(self,username):
        with sqlite3.connect(self.db) as c:
            r=c.execute("SELECT username,plan,is_admin FROM users WHERE username=?",(username,)).fetchone()
        return {"username":r[0],"plan":r[1],"is_admin":bool(r[2])} if r else None
    def _save_session(self,u):
        with open(self.session,"w") as f:f.write(u)
        return self._user(u)
    def current_user(self):
        try:
            with open(self.session) as f:return self._user(f.read().strip())
        except Exception:return None
    def logout(self):
        try:os.remove(self.session)
        except OSError:pass
    def is_admin(self):
        u=self.current_user()
        return bool(u and u["is_admin"])
