# python-for-android service entry point.
# A production service should supervise dedicated worker processes and persist job metadata.
import os, time, json
from jnius import autoclass
PythonService = autoclass('org.kivy.android.PythonService')
PythonService.mService.setForeground(True)
while True:
    time.sleep(30)
