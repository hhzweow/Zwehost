import os, subprocess, sys, uuid, threading, time, signal
class BotRunner:
    """Independent subprocess runner for desktop/Linux; Android service integration is required for production."""
    def __init__(self,workspace,log_callback=None,change_callback=None):
        self.workspace=workspace; os.makedirs(workspace,exist_ok=True)
        self.jobs={}; self.log=log_callback or (lambda x:None); self.changed=change_callback or (lambda:None)
        self.plan="FREE"; self.started_at={}
    def set_plan(self,plan): self.plan=plan.upper()
    def _limit(self): return 5 if self.plan=="PRO" else 2
    def _duration(self): return 24*3600 if self.plan=="PRO" else 2*3600
    def start(self,path):
        path=os.path.abspath(path)
        if not path.lower().endswith(".py") or not os.path.isfile(path):
            raise ValueError("Bot file not found. Add a valid .py file to the workspace.")
        running=[j for j in self.jobs.values() if j["process"].poll() is None]
        if len(running)>=self._limit(): raise ValueError(f"{self.plan} allows up to {self._limit()} active bots.")
        bid=uuid.uuid4().hex[:8]
        proc=subprocess.Popen([sys.executable,"-u",path],cwd=os.path.dirname(path),
            stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
        job={"id":bid,"path":path,"process":proc,"started":time.time()}
        self.jobs[bid]=job
        threading.Thread(target=self._read,args=(job,),daemon=True).start()
        threading.Thread(target=self._watch,args=(job,),daemon=True).start()
        self.changed(); return bid
    def _read(self,job):
        try:
            for line in iter(job["process"].stdout.readline,""):
                self.log(f'[{job["id"]}] {line.rstrip()}')
        except Exception as e:self.log(str(e))
    def _watch(self,job):
        while job["process"].poll() is None:
            if time.time()-job["started"]>=self._duration():
                self.log(f'[{job["id"]}] Session time limit reached; stopping.')
                self.stop(job["id"]); break
            time.sleep(2)
        self.changed()
    def stop(self,bid):
        j=self.jobs.get(bid)
        if j and j["process"].poll() is None:
            j["process"].terminate()
            try:j["process"].wait(timeout=4)
            except subprocess.TimeoutExpired:j["process"].kill()
        self.changed()
    def delete(self,bid):
        self.stop(bid)
        self.jobs.pop(bid,None); self.changed()
    def list_bots(self):
        out=[]
        for j in self.jobs.values():
            out.append({"id":j["id"],"name":os.path.basename(j["path"]),
                        "status":"RUNNING" if j["process"].poll() is None else "STOPPED"})
        return out
